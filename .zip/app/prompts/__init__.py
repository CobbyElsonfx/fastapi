"""LLM prompt modules."""
