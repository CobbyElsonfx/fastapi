"""Pydantic request/response models."""
