"""AI service application package."""
